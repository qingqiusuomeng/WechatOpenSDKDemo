//
//  main.m
//  WechatOpenSDKDemo
//
//  Created by 李秋 on 2018/5/23.
//  Copyright © 2018年 baidu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
